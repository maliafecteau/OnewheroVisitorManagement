﻿using OnewheroVisitorManagement.View;
using OnewheroVisitorManagement.ViewModel;
using System;
using System.Collections.Generic;
using System.Data.SQLite;
using System.Diagnostics;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Navigation;


namespace OnewheroVisitorManagement
{
    /// <summary>
    /// Interaction logic for RegisterPage.xaml
    /// </summary>
    public partial class RegisterPage : UserControl
    {
        string connectionString = "Data Source=users.db;Version=3;";
        private int? eventID;
        private double cost = 0;
        private List<Border> dayBoxes = new List<Border>();
        private List<bool> selectedDays = new List<bool> { false, false, false, false, false };
        
        public int CurrentNum
        {
            get { return Convert.ToInt32(txtNumTickets.Text); }
            set { txtNumTickets.Text = value.ToString(); }
        }

        public double TotalCost
        {
            get { return CurrentNum * cost; }
            set { txtTotalCost.Text = "Total Cost: $" + value.ToString("F2"); }
        }

        public RegisterPage(string? argument)
        {
            InitializeComponent();
            CurrentNum = 0;
            TotalCost = 0;
            
            // Initialize day boxes list
            dayBoxes.Add(dayBox1);
            dayBoxes.Add(dayBox2);
            dayBoxes.Add(dayBox3);
            dayBoxes.Add(dayBox4);
            dayBoxes.Add(dayBox5);
            
            if (!string.IsNullOrEmpty(argument))
            {
                eventID = Convert.ToInt32(argument);
                FindEvent();
            }
            else
            {
                // Hide ticket selector if no event ID provided
                txtBlockCost.Visibility = Visibility.Collapsed;
                daysOfWeekPanel.Visibility = Visibility.Collapsed;
                txtBlockNumTickets.Visibility = Visibility.Collapsed;
                ticketSelectorPanel.Visibility = Visibility.Collapsed;
                txtTotalCost.Visibility = Visibility.Collapsed;
            }
        }

        private void FindEvent()
        {
            if (eventID == null) return;
            
            foreach (Event ev in MainWindow.EventsList)
            {
                if (ev.EventID == eventID.Value)
                {
                    cost = ev.EventCost;
                    txtBlockCost.Text = "Cost per Ticket: $" + cost.ToString("F2");
                    break;
                }
            }
        }

        public void Decr_Click(object sender, RoutedEventArgs e)
        {
            CurrentNum--;
            TotalCost = CurrentNum * cost;
            
            if (CurrentNum <= 0)
            {
                CurrentNum = 0;
                TotalCost = CurrentNum * cost;
            }
        }

        public void Incr_Click(object sender, RoutedEventArgs e)
        {
            CurrentNum++;
            TotalCost = CurrentNum * cost;
        }

        private void DayBox_Click(object sender, MouseButtonEventArgs e)
        {
            Border? clickedBox = sender as Border;
            if (clickedBox != null)
            {
                int index = dayBoxes.IndexOf(clickedBox);
                if (index >= 0 && index < selectedDays.Count)
                {
                    selectedDays[index] = !selectedDays[index];
                    
                    // Toggle background color
                    if (selectedDays[index])
                    {
                        clickedBox.Background = new SolidColorBrush(Color.FromRgb(74, 144, 226)); // Blue
                        if (clickedBox.Child is TextBlock textBlock)
                        {
                            textBlock.Foreground = Brushes.White;
                        }
                    }
                    else
                    {
                        clickedBox.Background = Brushes.White;
                        if (clickedBox.Child is TextBlock textBlock)
                        {
                            textBlock.Foreground = new SolidColorBrush(Color.FromRgb(47, 79, 79)); // DarkSlateGray
                        }
                    }
                }
            }
        }

        private void Register_Click(object sender, RoutedEventArgs e)
        {
            if (txtFullName == null)
            {
                MessageBox.Show("Please enter your full name", "Input Error", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }
            else if (txtEmail == null)
            {
                MessageBox.Show("Please enter your email", "Input Error", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            } else
            {
                string fullName = txtFullName.Text.Trim();
                string email = txtEmail.Text.Trim();

                try
                {
                    using (var connection = new SQLiteConnection(connectionString))
                    {
                        connection.Open();
                        string query = "SELECT COUNT(*) FROM Visitors WHERE ContactEmail=@ContactEmail;";
                        using (var cmd = new SQLiteCommand(query, connection))
                        {
                            cmd.Parameters.AddWithValue("@ContactEmail", email);

                            int Count = Convert.ToInt32(cmd.ExecuteScalar());
                            if (Count > 0)
                            {
                                MessageBox.Show("Welcome back " + fullName + "! We found your previous registration and filled in your details for you.", "Welcome Back", MessageBoxButton.OK, MessageBoxImage.Information);
                                RegisterContent.Content = new VisitorNav();

                            }
                            else
                            {
                                RegisterContent.Content = new RegisterNewVisitor(fullName, email);
                            }
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Registration failed. Please try again", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
                    Console.WriteLine(ex.Message);
                    txtFullName.Clear();
                    txtEmail.Clear();
                }
            }
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {

        }
    }
}
