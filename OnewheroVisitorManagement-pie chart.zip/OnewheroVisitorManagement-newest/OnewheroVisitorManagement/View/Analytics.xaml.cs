﻿using System;
using System.Collections.Generic;
using System.Data.SQLite;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace OnewheroVisitorManagement.View
{
    /// <summary>
    /// Interaction logic for Analytics.xaml
    /// </summary>
    /// 

    public class PieItem
    {
        public string Category { get; set; } = string.Empty;
        public int Value { get; set; }
    }
    public partial class Analytics : UserControl
    {
        string connectionString = "Data Source=users.db;Version=3;";
        string query = "SELECT Interests FROM Visitors WHERE Interests IS NOT NULL AND Interests != ''";
        
        public Analytics()
        {
            InitializeComponent();
            LoadPieChart();
        }

        private void LoadPieChart()
        {
            var interestCounts = new Dictionary<string, int>();
            
            // Initialize all possible interest categories
            string[] interestCategories = { "Native Birds", "Reptiles", "History", "Sports", "Music", "Literature" };
            foreach (var category in interestCategories)
            {
                interestCounts[category] = 0;
            }

            using (var connection = new SQLiteConnection(connectionString))
            {
                connection.Open();
                SQLiteCommand command = new SQLiteCommand(query, connection);
                SQLiteDataReader reader = command.ExecuteReader();

                while (reader.Read())
                {
                    if (!reader.IsDBNull(0))
                    {
                        string interests = reader.GetString(0);
                        
                        // Parse comma-separated interests
                        if (!string.IsNullOrWhiteSpace(interests))
                        {
                            string[] individualInterests = interests.Split(new[] { ',' }, StringSplitOptions.RemoveEmptyEntries);
                            
                            foreach (var interest in individualInterests)
                            {
                                string trimmedInterest = interest.Trim();
                                
                                // Count each interest
                                if (interestCounts.ContainsKey(trimmedInterest))
                                {
                                    interestCounts[trimmedInterest]++;
                                }
                                else
                                {
                                    // Handle any unexpected interest values
                                    interestCounts[trimmedInterest] = 1;
                                }
                            }
                        }
                    }
                }
            }

            // Convert dictionary to list of PieItem objects
            var data = interestCounts
                .Where(kvp => kvp.Value > 0) // Only include interests that have at least one selection
                .Select(kvp => new PieItem
                {
                    Category = kvp.Key,
                    Value = kvp.Value
                })
                .ToList();

            // Bind data to the pie chart by setting DataContext
            // The PieSeries in XAML is bound to {Binding}, so we set the DataContext to our data
            DataContext = data;
            
            // The legend should automatically appear with the Category names from IndependentValuePath
            // If it doesn't show, we can try to access and configure it programmatically
            if (PieChart != null && InterestsPieSeries != null)
            {
                // Ensure the series is properly bound
                InterestsPieSeries.ItemsSource = data;
                
                // The legend is automatically generated from the IndependentValuePath (Category)
                // Each pie slice will have a legend entry showing the Category name
            }
        }
    }
}
