﻿using OnewheroVisitorManagement.Model;
using OnewheroVisitorManagement.View;
using OnewheroVisitorManagement.ViewModel;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Data;
using System.Data.SQLite;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace OnewheroVisitorManagement.View
{
    /// <summary>
    /// Interaction logic for Events.xaml
    /// </summary>
    public partial class VisitorEvents : UserControl
    {
        public VisitorEvents()
        {
            InitializeComponent();            
        }

        private void BookEvent_Click(object sender, RoutedEventArgs e)
        {
            Button? clickedButton = sender as Button;
            if (clickedButton != null && clickedButton.Tag != null)
            {
                string? argument = clickedButton.Tag.ToString();
                if (!string.IsNullOrEmpty(argument))
                {
                    MessageBox.Show($"Argument received: {argument}");
                    OnewheroVisitorManagement.RegisterPage register = new OnewheroVisitorManagement.RegisterPage(argument);
                    VisitorEventsContent.Content = register;
                }
            }
        }
    }
}