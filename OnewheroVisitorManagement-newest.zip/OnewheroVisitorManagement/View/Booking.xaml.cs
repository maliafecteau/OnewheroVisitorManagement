﻿using OnewheroVisitorManagement.Model;
using OnewheroVisitorManagement.ViewModel;
using System;
using System.Collections.Generic;
using System.Data.SQLite;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace OnewheroVisitorManagement.View
{
    /// <summary>
    /// Interaction logic for Booking.xaml
    /// </summary>
    public partial class Booking : UserControl
    {
        public int CurrentNum
        {
            get { return Convert.ToInt32(txtNumTickets.Text); }
            set { txtNumTickets.Text = value.ToString();}
        }
        public int ThisEventID;
        public double cost;
        public string bookingDate, eventName;
        string connectionString = "Data Source=users.db;Version=3;";

        public double TotalCost
        {
            get { return CurrentNum*cost; }
            set { txtTotalCost.Text = "Total Cost: " + value.ToString(); }
        }

        public Booking(string eventID)
        {
            
            InitializeComponent();
            DataContext = this;
            ThisEventID = Convert.ToInt32(eventID);
            Debug.WriteLine("ThisEventID: " +  ThisEventID);
            CurrentNum = 0;
            TotalCost = 0;
            FindEvent();
        }

        private void FindEvent()
        {
            foreach (Event ev in MainWindow.EventsList)
            {
                Debug.WriteLine(ev.EventName);
                Debug.WriteLine(ev.EventDates);
                Debug.WriteLine(ev.EventDesc);
                Debug.WriteLine(ev.EventCost);
                if (ev.EventID == ThisEventID)
                    {
                        Debug.WriteLine(ThisEventID);
                        Debug.WriteLine(ev.EventID);
                        cost = Convert.ToInt32(ev.EventCost);
                        txtBlockCost.Text = "Cost per Ticket: $" + cost;
                        bookingDate = ev.EventDates;
                        eventName = ev.EventName;
                        txtEventName.Text = ev.EventName;
                        
                    }

            }
            Debug.Write(bookingDate);
            Debug.Write("$" + cost);
            Debug.Write(eventName);
        }
        public void Decr_Click(object sender, RoutedEventArgs e)
        {
            CurrentNum--;
        TotalCost = CurrentNum * cost;
                
            if (CurrentNum <= 0)
            {
                CurrentNum = 0;
                TotalCost = CurrentNum * cost;
            }
        }

        public void Incr_Click(object sender, RoutedEventArgs e)
        {
            CurrentNum++;
            Debug.Write(CurrentNum);
            TotalCost = CurrentNum * cost;
        }

        public void ConfirmBook_Click(object sender, RoutedEventArgs e)
        {
            if (CurrentNum == 0)
            {
                MessageBox.Show("Please fill in all fields.", "Input Error", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            using (var connection = new SQLiteConnection(connectionString))
            {
                connection.Open();
                string insertBookingQuery = "INSERT INTO Bookings (EventID, BookingDate, NumTickets, TotalCost) VALUES (@EventID, @BookingDate, @NumTickets, @TotalCost);";
                using (var insertCmd = new SQLiteCommand(insertBookingQuery, connection))
                {
                    insertCmd.Parameters.AddWithValue("@EventID", ThisEventID);
                    insertCmd.Parameters.AddWithValue("@BookingDate", bookingDate);
                    insertCmd.Parameters.AddWithValue("@NumTickets", CurrentNum);
                    insertCmd.Parameters.AddWithValue("@TotalCost", TotalCost);
                    insertCmd.ExecuteNonQuery();
                }
                MessageBox.Show($"Booking successful! Total cost: ${TotalCost}", "Success", MessageBoxButton.OK, MessageBoxImage.Information);
                popup.IsOpen = true;
            }
        }


        }
    }