﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace OnewheroVisitorManagement.View
{
    /// <summary>
    /// Interaction logic for Events.xaml
    /// </summary>
    public partial class AdminEvents : UserControl
    {
        public AdminEvents()
        {
            InitializeComponent();
        }

        private void BackButton_Click(object sender, RoutedEventArgs e)
        {
            // Find parent Page and execute BackCommand
            DependencyObject parent = this;
            while (parent != null && !(parent is Page))
            {
                parent = System.Windows.Media.VisualTreeHelper.GetParent(parent);
            }
            
            if (parent is Page page && page.DataContext is ViewModel.NavigationVM navVM)
            {
                navVM.BackCommand?.Execute(null);
            }
        }
    }
}
