﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SQLite;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace OnewheroVisitorManagement.View
{
    /// <summary>
    /// Interaction logic for Analytics.xaml
    /// </summary>
    public class PieItem
    {
        public string Category { get; set; } = string.Empty;
        public int Value { get; set; }
    }
    
    public partial class Analytics : UserControl
    {
        string connectionString = "Data Source=users.db;Version=3;";
        private bool isVisitorsData = true;

        public Analytics()
        {
            InitializeComponent();
            // Use Loaded event to ensure XAML elements are fully initialized
            this.Loaded += Analytics_Loaded;
        }

        private void Analytics_Loaded(object sender, RoutedEventArgs e)
        {
            // Ensure we're on the UI thread and elements are fully loaded
            Dispatcher.BeginInvoke(new Action(() =>
            {
                LoadVisitorsData();
            }), System.Windows.Threading.DispatcherPriority.Loaded);
        }

        private void BackButton_Click(object sender, RoutedEventArgs e)
        {
            // Find parent Page and execute BackCommand
            DependencyObject parent = this;
            while (parent != null && !(parent is Page))
            {
                parent = System.Windows.Media.VisualTreeHelper.GetParent(parent);
            }
            
            if (parent is Page page && page.DataContext is ViewModel.NavigationVM navVM)
            {
                navVM.BackCommand?.Execute(null);
            }
        }

        private void DataSource_Checked(object sender, RoutedEventArgs e)
        {
            RadioButton radioButton = sender as RadioButton;
            if (radioButton != null)
            {
                if (radioButton.Name == "VisitorsRadio")
                {
                    isVisitorsData = true;
                    LoadVisitorsData();
                }
                else if (radioButton.Name == "EventsRadio")
                {
                    isVisitorsData = false;
                    LoadEventsData();
                }
            }
        }

        private void LoadVisitorsData()
        {
            var interestCounts = new Dictionary<string, int>();

            // Initialize all possible interest categories
            string[] interestCategories = { "Native Birds", "Reptiles", "History", "Sports", "Music", "Literature" };
            foreach (var category in interestCategories)
            {
                interestCounts[category] = 0;
            }

            string query = "SELECT Interests FROM Visitors WHERE Interests IS NOT NULL AND Interests != ''";
            
            using (var connection = new SQLiteConnection(connectionString))
            {
                connection.Open();
                SQLiteCommand command = new SQLiteCommand(query, connection);
                SQLiteDataReader reader = command.ExecuteReader();

                while (reader.Read())
                {
                    if (!reader.IsDBNull(0))
                    {
                        string interests = reader.GetString(0);

                        // Parse comma-separated interests
                        if (!string.IsNullOrWhiteSpace(interests))
                        {
                            string[] individualInterests = interests.Split(new[] { ',' }, StringSplitOptions.RemoveEmptyEntries);

                            foreach (var interest in individualInterests)
                            {
                                string trimmedInterest = interest.Trim();

                                // Count each interest
                                if (interestCounts.ContainsKey(trimmedInterest))
                                {
                                    interestCounts[trimmedInterest]++;
                                }
                                else
                                {
                                    // Handle any unexpected interest values
                                    interestCounts[trimmedInterest] = 1;
                                }
                            }
                        }
                    }
                }
            }

            // Convert dictionary to list of PieItem objects
            var data = interestCounts
                .Where(kvp => kvp.Value > 0 && !string.IsNullOrEmpty(kvp.Key)) // Only include interests that have at least one selection and valid key
                .Select(kvp => new PieItem
                {
                    Category = kvp.Key ?? string.Empty,
                    Value = kvp.Value
                })
                .ToList();

            // Update chart title and bind data (with null checks)
            try
            {
                if (PieChart != null)
                {
                    PieChart.Title = "Visitor Interests Distribution";
                }
            }
            catch { }

            try
            {
                if (InterestsPieSeries != null)
                {
                    InterestsPieSeries.Title = "Interests Distribution";
                    InterestsPieSeries.ItemsSource = data;
                }
            }
            catch { }

            // Bind data to the pie chart
            DataContext = data;
        }

        private void LoadEventsData()
        {
            var eventTicketCounts = new Dictionary<string, int>();
            
            // Query to get ticket counts from Bookings table grouped by Event
            // This works whether or not TicketCount column exists in Events table
            string query = @"
                SELECT e.EventID, e.EventName, COALESCE(SUM(b.NumTickets), 0) as TicketCount
                FROM Events e
                LEFT JOIN Bookings b ON e.EventID = b.EventID
                GROUP BY e.EventID, e.EventName";

            using (var connection = new SQLiteConnection(connectionString))
            {
                connection.Open();
                SQLiteCommand command = new SQLiteCommand(query, connection);
                SQLiteDataReader reader = command.ExecuteReader();

                while (reader.Read())
                {
                    if (!reader.IsDBNull(0))
                    {
                        string eventName = reader.GetString(1);
                        int ticketCount = Convert.ToInt32(reader.GetValue(2));
                        eventTicketCounts[eventName] = ticketCount;
                    }
                }
            }

            // Convert dictionary to list of PieItem objects
            var data = eventTicketCounts
                .Where(kvp => kvp.Value > 0 && !string.IsNullOrEmpty(kvp.Key)) // Only include events that have at least one ticket sold and valid key
                .Select(kvp => new PieItem
                {
                    Category = kvp.Key ?? string.Empty,
                    Value = kvp.Value
                })
                .ToList();

            // If no events have tickets, show all events with 0
            if (data.Count == 0)
            {
                data = eventTicketCounts
                    .Where(kvp => !string.IsNullOrEmpty(kvp.Key))
                    .Select(kvp => new PieItem
                    {
                        Category = kvp.Key ?? string.Empty,
                        Value = kvp.Value
                    })
                    .ToList();
            }

            // Update chart title and bind data (with null checks)
            try
            {
                if (PieChart != null)
                {
                    PieChart.Title = "Event Ticket Sales Distribution";
                }
            }
            catch { }

            try
            {
                if (InterestsPieSeries != null)
                {
                    InterestsPieSeries.Title = "Tickets Sold per Event";
                    InterestsPieSeries.ItemsSource = data;
                }
            }
            catch { }

            // Bind data to the pie chart
            DataContext = data;
        }
    }
}
