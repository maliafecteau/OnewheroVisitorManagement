﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OnewheroVisitorManagement.Utilities;
using System.Windows.Input;
using OnewheroVisitorManagement.View;

namespace OnewheroVisitorManagement.ViewModel
{
    public class NavigationVM : ViewModelBase
    {
        private object _currentView;
        private Stack<object> _navigationHistory = new Stack<object>();
        private string _userType;

        public object CurrentView
        {
            get { return _currentView; }
            set { _currentView = value; OnPropertyChanged(); }
        }

        public ICommand AdminPageCommand { get; set; }
        public ICommand VisitorPageCommand { get; set; }
        public ICommand VCCommand { get; set; }
        public ICommand AnalyticsCommand { get; set; }
        public ICommand AboutCommand { get; set; }
        public ICommand AdminEventsCommand { get; set; }
        public ICommand VisitorEventsCommand { get; set; }
        public ICommand ContactCommand { get; set; }
        public ICommand LogoutCommand { get; set; }
        public ICommand ExitCommand { get; set; }
        public ICommand BackCommand { get; set; }

        private void NavigateToView(object newView)
        {
            // Push current view to history if it exists
            if (_currentView != null)
            {
                _navigationHistory.Push(_currentView);
            }
            CurrentView = newView;
        }

        private void AdminPage(object obj) => NavigateToView(new AdminPage()); 
        private void VisitorPage(object obj) => NavigateToView(new VisitorPage());
        private void VisitorControl(object obj) => NavigateToView(new VisitorControl());
        private void Analytics(object obj) => NavigateToView(new Analytics());
        private void About(object obj) => NavigateToView(new About());
        private void AdminEvents(object obj) => NavigateToView(new AdminEvents());
        private void VisitorEvents(object obj) => NavigateToView(new VisitorEventsVM());
        private void Contact(object obj) => NavigateToView(new Contact());
        private void Logout(object obj) => CurrentView = new MainWindow();
        private void Exit(object obj) => Environment.Exit(0);

        private void Back(object obj)
        {
            if (_navigationHistory.Count > 0)
            {
                CurrentView = _navigationHistory.Pop();
            }
            else
            {
                // If no history, go to default page
                if (_userType == "Admin")
                {
                    CurrentView = new AdminPage();
                }
                else if (_userType == "Visitor")
                {
                    CurrentView = new VisitorPage();
                }
            }
        }

        public NavigationVM(string user)
        {
            _userType = user;
            AdminPageCommand = new RelayCommand(AdminPage);
            VisitorPageCommand = new RelayCommand(VisitorPage);
            VCCommand = new RelayCommand(VisitorControl);
            AnalyticsCommand = new RelayCommand(Analytics);
            AboutCommand = new RelayCommand(About);
            AdminEventsCommand = new RelayCommand(AdminEvents);
            VisitorEventsCommand = new RelayCommand(VisitorEvents);
            ContactCommand = new RelayCommand(Contact);
            LogoutCommand = new RelayCommand(Logout);
            ExitCommand = new RelayCommand(Exit);
            BackCommand = new RelayCommand(Back);

            // Set default view
            if (user == "Admin")
            {
                CurrentView = new AdminPage();
            }
            else if (user == "Visitor")
            {
                CurrentView = new VisitorPage();
            }
        }

    }
}
